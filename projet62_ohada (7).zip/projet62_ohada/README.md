# Projet 62 — Plateforme OHADA

## Installation
1. Importer `sql/schema.sql` dans phpMyAdmin.
2. Configurer `config/database.php`.
3. Accéder via `http://localhost/projet62_ohada/public/`.
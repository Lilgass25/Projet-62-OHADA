-- Script de création de la base de données
CREATE DATABASE IF NOT EXISTS `projet62_ohada`;
USE `projet62_ohada`;

CREATE TABLE `utilisateurs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(100) NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin', 'juriste', 'consultant') DEFAULT 'consultant'
);

-- Insérer un admin pour test
INSERT INTO `utilisateurs` (`email`, `password`, `role`) VALUES 
('admin@cabinet-ohada.sn', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Autres tables simplifiées pour démonstration
CREATE TABLE `societes` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nom` VARCHAR(100) NOT NULL,
  `forme` VARCHAR(50),
  `capital` DECIMAL(15,2)
);